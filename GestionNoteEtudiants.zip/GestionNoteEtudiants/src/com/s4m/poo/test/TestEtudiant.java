package com.s4m.poo.test;

import com.s4m.poo.basics.Etudiant;
import com.s4m.poo.basics.Notation;
import com.s4m.poo.db.Database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class TestEtudiant {

    public static void main(String[] args) {

        // --- Cas 1 : Étudiant Admis (Aristote) ---

        // 1. Création de l'objet Etudiant avec les données de base (nom, prenom, numéro)
        Etudiant e1 = new Etudiant("Du Jardin", "Aristote", "E001");

        // 2. Définition des notes (Matière, Coef, Note)
        List<Notation> notes1 = new ArrayList<>();
        notes1.add(new Notation("Java POO", 3, 18.0f));
        notes1.add(new Notation("BDD SQL", 2, 17.0f));
        notes1.add(new Notation("Anglais", 1, 15.0f));
        e1.setNotations(notes1); // On ajoute les notes à l'objet Étudiant

        // 3. Traitements métier (Calcul de la moyenne et de l'avis)
        e1.calculeerMoyenne();
        e1.donnerAvis();

        // 4. Sauvegarde dans la base de données
        e1.saveToDB(); // Sauvegarde l'étudiant et récupère son ID
        for (Notation n : e1.getNotations()) {
            n.saveToDB(e1.getId()); // Sauvegarde les notes, liées par l'ID de l'étudiant
        }
        e1.updateDB(); // Mise à jour de la moyenne et de l'avis dans la table Etudiants

        // 5. Affichage des informations récupérées depuis la base
        afficherDepuisBase(e1.getId());

        // --- Cas 2 : Étudiant Ajourné (Amel) ---
        Etudiant e2 = new Etudiant("Benali", "Amel", "E002");
        List<Notation> notes2 = new ArrayList<>();
        notes2.add(new Notation("Java POO", 3, 7.5f));
        notes2.add(new Notation("BDD SQL", 2, 8.0f));
        notes2.add(new Notation("Anglais", 1, 10.0f));
        e2.setNotations(notes2);

        e2.calculeerMoyenne();
        e2.donnerAvis();

        e2.saveToDB();
        for (Notation n : e2.getNotations()) {
            n.saveToDB(e2.getId());
        }
        e2.updateDB();
        afficherDepuisBase(e2.getId());
    }

    /**
     * Récupère toutes les informations d'un étudiant et ses notes depuis la base de données
     * et les affiche.
     * @param idEtudiant l'ID de l'étudiant à afficher
     */
    public static void afficherDepuisBase(int idEtudiant) {
        System.out.println("\n--- Affichage Complet depuis la Base de Données (ID: " + idEtudiant + ") ---");

        // Utilisation de try-with-resources pour une gestion sûre des connexions
        try (Connection con = Database.getConnection()) {
            if (con == null) return;

            // 1. Récupération de l'étudiant
            // Utilisation de etudiant_id (nom de colonne de la PK dans le script SQL)
            String sql1 = "SELECT nom, prenom, numero_etudiant, moyenne, avis FROM etudiants WHERE etudiant_id = ?";
            try (PreparedStatement ps1 = con.prepareStatement(sql1)) {
                ps1.setInt(1, idEtudiant);
                try (ResultSet rs1 = ps1.executeQuery()) {
                    if (rs1.next()) {
                        System.out.println("Nom complet : " + rs1.getString("prenom") + " " + rs1.getString("nom"));
                        System.out.println("Numéro étudiant : " + rs1.getString("numero_etudiant"));
                        System.out.printf("Moyenne : %.2f\n", rs1.getFloat("moyenne"));
                        System.out.println("Avis : " + rs1.getString("avis"));
                    }
                }
            }

            System.out.println("Notes associées :");

            // 2. Récupération des notations
            String sql2 = "SELECT matiere, coefficient, note FROM notations WHERE etudiant_id = ?";
            try (PreparedStatement ps2 = con.prepareStatement(sql2)) {
                ps2.setInt(1, idEtudiant);
                try (ResultSet rs2 = ps2.executeQuery()) {
                    while (rs2.next()) {
                        System.out.println(
                                "  - " + rs2.getString("matiere") +
                                        ", Coef: " + rs2.getInt("coefficient") +
                                        ", Note: " + String.format("%.2f", rs2.getFloat("note"))
                        );
                    }
                }
            }
            System.out.println("---------------------------------------------------------");

        } catch (Exception e) {
            System.err.println("Erreur lors de l'affichage depuis la base de données.");
            e.printStackTrace();
        }
    }
}