package com.s4m.poo.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Database {

    // Utilisation des constantes pour une meilleure lisibilité
    private static final String DRIVER = "com.mysql.cj.jdbc.Driver";
    // ATTENTION : Si votre base s'appelle 'gestion_notes', modifiez cette ligne
    private static final String URL = "jdbc:mysql://localhost:3306/gestion_notes_etudiants";
    private static final String USER = "root";
    // ATTENTION : Si 'root' a un mot de passe, il doit être renseigné ici.
    private static final String PASSWORD = "";

    public static Connection getConnection() {
        try {
            // Chargement explicite du driver (bonne pratique)
            Class.forName(DRIVER);

            // Établissement de la connexion
            return DriverManager.getConnection(URL, USER, PASSWORD);

        } catch (ClassNotFoundException e) {
            // Si le JAR du driver n'est pas dans le classpath
            System.err.println("Erreur: Driver JDBC non trouvé ! Assurez-vous que le JAR est dans le classpath.");
            System.err.println("Détails: " + e.getMessage());
            return null;
        } catch (SQLException e) {
            // Erreurs de connexion (mot de passe, URL, base de données inexistante, serveur down)
            System.err.println("Erreur de connexion à la base de données !");
            System.err.println("Vérifiez l'URL, l'utilisateur et le mot de passe.");
            System.err.println("Message : " + e.getMessage());
            return null;
        }
    }
}