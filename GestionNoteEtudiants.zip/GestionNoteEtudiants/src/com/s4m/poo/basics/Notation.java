package com.s4m.poo.basics; // Uniformisation vers 'basic'

import com.s4m.poo.db.Database;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Notation {
    private int id; // Ajout de l'ID pour l'uniformité et si besoin futur (e.g., suppression)
    private String matiere; // Ajout de la matière, obligatoire selon la BD
    private int coef;
    private float note;

    // Constructeur mis à jour pour inclure la matière
    public Notation(String matiere, int coef, float note) {
        this.matiere = matiere;
        this.coef = coef;
        this.note = note;
    }

    // Constructeur pour la récupération (optionnel)
    public Notation(int id, String matiere, int coef, float note) {
        this(matiere, coef, note);
        this.id = id;
    }

    // --- Getters et Setters ---

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getMatiere() { return matiere; }
    public void setMatiere(String matiere) { this.matiere = matiere; }

    public int getCoef() { return coef; }
    public void setCoef(int coef) { this.coef = coef; }

    public float getNote() { return note; }
    public void setNote(float note) { this.note = note; }

    @Override
    public String toString() {
        return "Matière: " + matiere + ", Note: " + String.format("%.2f", note) + ", Coeff: " + coef;
    }

    // Objectif : Enregistrer la note dans la table Notations et la lier à l'étudiant
    public void saveToDB(int etudiantId) {
        // Utilisation de try-with-resources pour s'assurer que Connection et PreparedStatement sont fermés
        try (Connection con = Database.getConnection()) {

            if (con == null) {
                System.err.println("Erreur: Connexion à la base de données indisponible !");
                return;
            }

            // Requête SQL corrigée pour inclure la MATIERE
            String sql = "INSERT INTO notations (etudiant_id, matiere, note, coefficient) VALUES (?, ?, ?, ?)";

            try (PreparedStatement ps = con.prepareStatement(sql)) {
                ps.setInt(1, etudiantId);
                ps.setString(2, matiere); // Nouveau paramètre
                ps.setFloat(3, note);
                ps.setInt(4, coef);

                ps.executeUpdate();
                System.out.println("Note (" + matiere + ") enregistrée pour l'étudiant ID " + etudiantId + ".");
            }

        } catch (SQLException e) {
            System.err.println("Erreur SQL lors de l'insertion de la notation !");
            e.printStackTrace();
        }
    }
}