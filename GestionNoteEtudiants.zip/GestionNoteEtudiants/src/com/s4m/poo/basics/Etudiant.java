package com.s4m.poo.basics; // Assurez-vous d'utiliser un seul nom de package (basic ou basics)

import java.util.ArrayList;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.List; // Utiliser List est souvent mieux qu'ArrayList dans les attributs
import com.s4m.poo.db.Database; // Import de la classe de gestion de la BD

public class Etudiant {
    private int id;
    private String nom;
    private String prenom; // Ajouté pour correspondre au modèle de la BD
    private String numeroEtudiant; // Ajouté pour correspondre au modèle de la BD (UNIQUE)
    private String avis;
    private float moyenne;
    private List<Notation> notations; // Utilisation de List

    // Constructeur : prend les infos de base
    public Etudiant(String nom, String prenom, String numeroEtudiant) {
        this.setNom(nom);
        this.setPrenom(prenom);
        this.setNumeroEtudiant(numeroEtudiant);
        this.moyenne = 0.0f;
        this.avis = "Non calcule"; // Initialisation
        this.notations = new ArrayList<>(); // Initialiser la liste de notes
    }

    // Constructeur complet (utile pour la récupération depuis la BD)
    public Etudiant(int id, String nom, String prenom, String numeroEtudiant, float moyenne, String avis) {
        this(nom, prenom, numeroEtudiant); // Appel du constructeur principal
        this.id = id;
        this.moyenne = moyenne;
        this.avis = avis;
    }

    // --- Getters et Setters ---

    public int getId() { return id; }
    // Setter pour l'ID, nécessaire après la sauvegarde en BD
    public void setId(int id) { this.id = id; }

    public String getNom() { return nom; }
    public void setNom(String nom) { this.nom = nom; }

    public String getPrenom() { return prenom; }
    public void setPrenom(String prenom) { this.prenom = prenom; }

    public String getNumeroEtudiant() { return numeroEtudiant; }
    public void setNumeroEtudiant(String numeroEtudiant) { this.numeroEtudiant = numeroEtudiant; }

    public String getAvis() { return avis; }
    public void setAvis(String avis) { this.avis = avis; }

    public float getMoyenne() { return moyenne; }
    public void setMoyenne(float moyenne) { this.moyenne = moyenne; }

    public List<Notation> getNotations() { return notations; }
    public void setNotations(List<Notation> notations) { this.notations = notations; }

    // --- Méthodes Métier ---

    public void calculeerMoyenne() {
        if (notations == null || notations.isEmpty()) {
            this.moyenne = 0.0f;
            return;
        }

        float sumCoef = 0.0f;
        float sumCoefxNote = 0.0f;

        for (Notation n : notations) {
            sumCoef += n.getCoef();
            sumCoefxNote += n.getCoef() * n.getNote();
        }

        if (sumCoef != 0) {
            // S'assurer de la division en virgule flottante
            this.moyenne = sumCoefxNote / sumCoef;
        } else {
            this.moyenne = 0.0f;
        }
    }

    public void donnerAvis() {
        if(moyenne >= 10) {
            this.avis = "Admis";
        } else {
            this.avis = "Ajourne";
        }
    }

    public void afficher() {
        System.out.println("--- Fiche Étudiant (ID: " + id + ") ---");
        System.out.println("Nom complet : " + prenom + " " + nom + " (" + numeroEtudiant + ")");
        System.out.printf("Moyenne : %.2f\n", moyenne); // Affichage formaté
        System.out.println("Avis : " + avis);
        System.out.println("Notes associées :");
        if (notations.isEmpty()) {
            System.out.println("  (Aucune note trouvée)");
        } else {
            for (Notation n : notations) {
                System.out.println("  " + n.toString()); // Assurez-vous que Notation a un bon toString()
            }
        }
        System.out.println("--------------------------------------");
    }

    // --- Méthodes d'accès à la BD ---

    // Objectif : Ajout d'un étudiant dans la table Etudiants
    public void saveToDB() {
        try (Connection con = Database.getConnection()) { // Utilisation du try-with-resources pour fermer la connexion

            if (con == null) {
                System.out.println("Erreur de connexion à la base de données !");
                return;
            }

            // Requête INSERT corrigée pour inclure prenom et numero_etudiant
            String sql = "INSERT INTO etudiants (nom, prenom, numero_etudiant, moyenne, avis) VALUES (?, ?, ?, ?, ?)";

            PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, nom);
            ps.setString(2, prenom);
            ps.setString(3, numeroEtudiant);
            ps.setFloat(4, moyenne);
            ps.setString(5, avis);

            ps.executeUpdate();

            // Récupération de l'ID généré par la BD
            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) {
                    this.id = rs.getInt(1);
                    System.out.println("Étudiant " + nom + " enregistré avec ID: " + this.id);
                }
            }

        } catch (Exception e) {
            System.err.println("Erreur lors de l'enregistrement de l'étudiant !");
            e.printStackTrace();
        }
    }

    // Objectif : Mise à jour de la moyenne et de l'avis de l'étudiant
    public void updateDB() {
        if (this.id == 0) {
            System.err.println("Erreur: L'étudiant n'a pas encore d'ID (non enregistré).");
            return;
        }

        try (Connection con = Database.getConnection()) {

            if (con == null) {
                System.out.println("Erreur de connexion à la base de données !");
                return;
            }

            // Requête UPDATE pour mettre à jour la moyenne et l'avis
            String sql = "UPDATE etudiants SET moyenne=?, avis=? WHERE etudiant_id=?";

            PreparedStatement ps = con.prepareStatement(sql);
            ps.setFloat(1, moyenne);
            ps.setString(2, avis);
            ps.setInt(3, id); // Utilisation de l'ID pour identifier l'étudiant

            int rowsAffected = ps.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Moyenne et avis de l'étudiant ID " + id + " mis à jour.");
            }

        } catch (Exception e) {
            System.err.println("Erreur lors de la mise à jour de l'étudiant !");
            e.printStackTrace();
        }
    }
}